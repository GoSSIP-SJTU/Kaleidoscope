#include "kscope.h"

/* ===================================================================== */
/* Main                                                                  */
/* ===================================================================== */

int main(int argc, char * argv[])
{
	//return kaleidoscope(argc, argv);
	//return data_profiler(argc, argv);
	//return entropy(argc, argv);
	//return bbl_tracer(argc, argv);
	//return bbl_profiler(argc, argv);
	//return memuse(argc, argv);
	//return u1301(argc, argv);
	//return test_rtn2(argc, argv);
	//return test_memLog(argc, argv);
	//return find_call(argc, argv);
	//return diff_mem(argc, argv);
	//return slow_data_profiler(argc, argv);
	///return func_data_profiler(argc, argv);
	//return func_entropy(argc, argv);
	//return func_ins_profiler(argc, argv);
	return ins_count(argc, argv);
	//return ins_kscope(argc, argv);
	//return access_addrs(argc, argv);
	//return func_ins_entropy(argc, argv);
	//return dcache(argc, argv);
	//return MemoryAccessAnalysis(argc, argv);
	//return func_addrs(argc, argv);
	//return FuncMemAccessAnalysis(argc,argv);
	//return essemble_tools(argc, argv);
}
